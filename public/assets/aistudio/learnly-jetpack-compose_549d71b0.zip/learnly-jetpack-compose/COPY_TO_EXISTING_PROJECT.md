# Copy into an existing Kotlin + Jetpack Compose app

If you already have an Android app and do not want a separate project:

1. Open your existing app in Android Studio.
2. Copy the composable functions and supporting data classes from `app/src/main/java/com/learnly/dashboard/MainActivity.kt` into your app's package or a new `LearnlyDashboardScreen.kt` file.
3. Change the first line (`package com.learnly.dashboard`) to match your app's package.
4. Keep your existing `MainActivity` and call `LearnlyDashboard()` from your existing `setContent { ... }`. Do not add a second launcher Activity unless you want one.
5. Ensure the app module includes the Compose BOM, `androidx.activity:activity-compose`, Compose Foundation, Material 3, and `androidx.compose.material:material-icons-extended` dependencies listed in `app/build.gradle.kts`.
6. If your app uses a custom navigation system, connect the four bottom tabs to your routes instead of using the prototype's local scroll navigation.

The `LearnlyDashboard()` function is currently private because this is a complete standalone app. If you copy it to another file and call it from `MainActivity`, change `private fun LearnlyDashboard()` to `fun LearnlyDashboard()` or keep the activity in the same source file. Also move or change visibility for any private types that your app needs to reference.

This prototype intentionally uses local sample data and state. Replace the seed `courseSeed` and `taskSeed` data with your repository/view-model data when integrating it into a real app.
