# Learnly Dashboard — Native Jetpack Compose Prototype

A native Android dashboard prototype built with **Kotlin + Jetpack Compose**. It is not a WebView and does not depend on Lovable.

## Reference layout implemented

The opening section follows the dark Midnight Focus / Nocturne reference:

- Avatar, greeting, 12-day streak pill, and notification control
- Dark rounded Today's Focus card with the 75 / 120 minute target, 63% pill, progress track, and purple Start studying CTA

The scrollable dashboard then follows the supplied section order:

1. Continue learning — purple gradient course card, translucent up-next panel, lesson progress and white Resume CTA
2. Your learning rhythm — light analytics card, 7D / 30D / 90D selectors, seven rounded bars, and consistency insight
3. Quick tools — pastel Notes / Flashcards / Quiz / Focus Timer tiles and a full-width focus CTA
4. Streak and Quiz Ace achievement cards
5. Horizontally scrollable dark course cards
6. Today's plan with interactive completion controls and schedule chips
7. Floating lavender bottom navigation

## Working prototype interactions

- Start studying / Start a focus session opens a 25-minute focus timer with start, pause and reset.
- Resume opens the selected course detail sheet.
- 7D, 30D and 90D change the study metric and chart values.
- Notes has an editable local note field.
- Flashcards reveal answers and cycle between sample cards.
- Quiz shows selectable answers and immediate feedback.
- Course cards and See all open course detail / list panels.
- Today's plan check controls update the completed-task count.
- Details, notifications, More and navigation tabs open their corresponding local panels or scroll destinations.

All data is sample data held locally in the app session. There is no authentication, remote database or live sync configured.

## Open and run in Android Studio

1. Extract the ZIP.
2. In Android Studio, choose **Open** and select the `learnly-jetpack-compose` project folder (the folder containing `settings.gradle.kts`).
3. Use JDK 17 for Gradle. Allow Android Studio to sync and download the Android Gradle Plugin and dependencies.
4. Select an Android emulator or connected device with Android 8.0 (API 26) or later.
5. Run the `app` configuration.

The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01, compileSdk 35, and targetSdk 35.

## Preview

`MainActivity.kt` contains a Compose Preview named **Learnly dashboard · mobile** at 390 × 844 dp. Open the file in Android Studio and use the Design / Split preview.

## Project structure

```text
learnly-jetpack-compose/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        ├── java/com/learnly/dashboard/MainActivity.kt
        └── res/values/styles.xml
```

## Important scope note

This is a standalone native prototype that reproduces the supplied visual references and local interactions. The two reference websites' backend, accounts, saved user data, and external API behavior are not connected. A device APK was not built in this environment because Android SDK / Gradle tooling is not installed here; Android Studio can sync and build the included project.
